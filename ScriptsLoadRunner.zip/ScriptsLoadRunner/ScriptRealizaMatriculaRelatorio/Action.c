Action()
{

	
	int i;
	char matriula[10];
	char teste[10];
	sprintf(matriula,"{matricula}");
	sprintf(teste,"{teste}");
	
	web_add_cookie("erp.contrast=0; DOMAIN=guriensino.unipampa.edu.br");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("guri", 
		"URL=https://guriensino.unipampa.edu.br/guri/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=public/themes/moder/imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/themes/moder/imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/themes/moder/imgs/novo_user.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/themes/moder/imgs/lock.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=public/themes/moder/imgs/diagonals_3.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_form("login",
		"Snapshot=t27.inf",
		ITEMDATA,
		"Name=txtPerfilLogin", "Value=PTL", ENDITEM,
		"Name=login", "Value={matricula}", ENDITEM,
		"Name=senha", "Value=123", ENDITEM,
		"Name=captcha", "Value=", ENDITEM,
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("principal", 
		"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/diagonals_5.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("{matricula}", 
		"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/getDadosPesquisaAndifesAlunoAjax/{matricula}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("painel", 
		"URL=https://guriensino.unipampa.edu.br/guri/pta/painel/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/diagonals_3.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_url("solicitar_matricula", 
		"URL=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/pta/painel/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_highlight-soft_15_5f8168_1x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-icons_cc0000_256x240.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-icons_ffffff_256x240.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_dots-small_65_bcbdbc_2x2.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_highlight-hard_100_eeeeee_1x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/seta_sobe_16_disabled.png", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/seta_sobe_16.png", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_highlight-hard_100_f6f6f6_1x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/delete_16.png", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/seta_desce_16.png", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/seta_desce_16_disabled.png", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/diagonals_3.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	
	lr_think_time(4);
	
	for(i = 0; i<11;i++){
		int j;
		
		for(j = 0; j<10;j++){
			
			if(matriula[j] == teste[j]){
					
					
			}else{
				
				lr_next_row("PORTAL_DO_ALUNO.csv");
				sprintf(teste,"{teste}");
				break;
			}
			if(j=9){
				
				web_submit_data("atuSolicit",
		"Action=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/atuSolicit",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/",
		"Snapshot=t32.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=idTurma", "Value={idTurma}", ENDITEM,
		"Name=tipo", "Value=A", ENDITEM,
		"Name=disc", "Value={idDisciplina}", ENDITEM,
		LAST);

			web_custom_request("isLogado", 
				"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/isLogado", 
				"Method=POST", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Referer=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/", 
				"Snapshot=t33.inf", 
				"Mode=HTML", 
				"EncType=", 
				EXTRARES, 
				"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
				LAST);
		
			web_submit_data("refreshColisoes", 
				"Action=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/refreshColisoes", 
				"Method=POST", 
				"RecContentType=text/html", 
				"Referer=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/", 
				"Snapshot=t34.inf", 
				"Mode=HTML", 
				ITEMDATA, 
				"Name=turmas", "Value=0, {idTurma}", ENDITEM, 
				LAST);
						
				web_revert_auto_header("X-Requested-With");
		
			web_add_auto_header("Upgrade-Insecure-Requests", 
				"1");
		
			web_submit_data("validarGravacao", 
				"Action=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/validarGravacao", 
				"Method=POST", 
				"EncType=multipart/form-data", 
				"RecContentType=text/html", 
				"Referer=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/", 
				"Snapshot=t35.inf", 
				"Mode=HTML", 
				ITEMDATA, 
				"Name=txtTema", "Value=https://guriensino.unipampa.edu.br/guri/public/themes/moder/", ENDITEM, 
				LAST);
		
			web_revert_auto_header("Upgrade-Insecure-Requests");
		
				
				lr_next_row("PORTAL_DO_ALUNO.csv");
				sprintf(teste,"{teste}");
				break;
				
			}
		}
	}

	
	web_url("solicitar_matricula_2", 
		"URL=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/pta/solicitar_matricula/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/seta_sobe_16_disabled.png", ENDITEM, 
		"Url=/guri/public/themes/moder/imgs/seta_desce_16_disabled.png", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		LAST);
	
	
	
	
	
	
	
	
	
	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(4);
/* Added by Async CodeGen.
ID=Poll_0
ScanType = Recording

The following URLs are considered part of this conversation:
	https://guriensino.unipampa.edu.br/guri/public/themes/moder//imgs/marcador-lista.png

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	Poll_0_RequestCB
	Poll_0_ResponseCB
 */
	web_reg_async_attributes("ID=Poll_0", 
		"Pattern=Poll", 
		"URL=https://guriensino.unipampa.edu.br/guri/public/themes/moder//imgs/marcador-lista.png", 
		"PollIntervalMs=8800", 
		"RequestCB=Poll_0_RequestCB", 
		"ResponseCB=Poll_0_ResponseCB", 
		LAST);

/* Added by Async CodeGen.
ID=Poll_1
ScanType = Recording

The following URLs are considered part of this conversation:
	https://guriensino.unipampa.edu.br/guri/public/themes/moder//imgs/busca.png

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	Poll_1_RequestCB
	Poll_1_ResponseCB
 */
	web_reg_async_attributes("ID=Poll_1", 
		"Pattern=Poll", 
		"URL=https://guriensino.unipampa.edu.br/guri/public/themes/moder//imgs/busca.png", 
		"PollIntervalMs=8800", 
		"RequestCB=Poll_1_RequestCB", 
		"ResponseCB=Poll_1_ResponseCB", 
		LAST);

/* Added by Async CodeGen.
ID=Poll_2
ScanType = Recording

The following URLs are considered part of this conversation:
	https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	Poll_2_RequestCB
	Poll_2_ResponseCB
 */
	web_reg_async_attributes("ID=Poll_2", 
		"Pattern=Poll", 
		"URL=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", 
		"PollIntervalMs=8800", 
		"RequestCB=Poll_2_RequestCB", 
		"ResponseCB=Poll_2_ResponseCB", 
		LAST);

/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_0
URLs: 
	/guri/public/themes/moder//imgs/marcador-lista.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_1
URLs: 
	/guri/public/themes/moder//imgs/busca.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_2
URLs: 
	/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png
 */
	web_url("principal", 
		"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/diagonals_5.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("{matricula}", 
		"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/getDadosPesquisaAndifesAlunoAjax/{matricula}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_0
URLs: 
	/guri/public/themes/moder//imgs/marcador-lista.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_1
URLs: 
	/guri/public/themes/moder//imgs/busca.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_2
URLs: 
	/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png
 */
	web_url("painel",
		"URL=https://guriensino.unipampa.edu.br/guri/pta/painel/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal",
		"Snapshot=t45.inf",
		"Mode=HTML",
		EXTRARES,
		"Url=http://detectportal.firefox.com/success.txt","Referer=",ENDITEM,
		"Url=/guri/public/themes/moder//imgs/diagonals_3.png","Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css",ENDITEM,
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_0
URLs: 
	/guri/public/themes/moder//imgs/marcador-lista.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_1
URLs: 
	/guri/public/themes/moder//imgs/busca.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_2
URLs: 
	/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png
 */
	web_url("listar",
		"URL=https://guriensino.unipampa.edu.br/guri/pta/relatorios/listar/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://guriensino.unipampa.edu.br/guri/pta/painel/",
		"Snapshot=t46.inf",
		"Mode=HTML",
		EXTRARES,
		"Url=http://detectportal.firefox.com/success.txt","Referer=",ENDITEM,
		LAST);

/* Added by Async CodeGen.
ID = Poll_2
 */
	web_stop_async("ID=Poll_2", 
		LAST);

/* Added by Async CodeGen.
ID = Poll_1
 */
	web_stop_async("ID=Poll_1", 
		LAST);

/* Added by Async CodeGen.
ID = Poll_0
 */
	web_stop_async("ID=Poll_0", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_image("Clique para gerar o relat�rio", 
		"Alt=Clique para gerar o relat�rio", 
		"Ordinal=1", 
		"Snapshot=t47.inf", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		LAST);

	return 0;
}