Action()
{

	web_add_cookie("erp.contrast=0; DOMAIN=guriensino.unipampa.edu.br");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("guri", 
		"URL=https://guriensino.unipampa.edu.br/guri/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=public/themes/moder/imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/themes/moder/imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/themes/moder/imgs/novo_user.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/themes/moder/imgs/lock.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		"Url=public/themes/moder/imgs/diagonals_3.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_form("login", 
		"Snapshot=t30.inf", 
		ITEMDATA, 
		"Name=txtPerfilLogin", "Value=PTL", ENDITEM, 
		"Name=login", "Value={matricula}", ENDITEM, 
		"Name=senha", "Value=123", ENDITEM, 
		"Name=captcha", "Value=", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(4);
	
/* Added by Async CodeGen.
ID=Poll_0
ScanType = Recording

The following URLs are considered part of this conversation:
	https://guriensino.unipampa.edu.br/guri/public/themes/moder//imgs/marcador-lista.png

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	Poll_0_RequestCB
	Poll_0_ResponseCB
 */
	web_reg_async_attributes("ID=Poll_0", 
		"Pattern=Poll", 
		"URL=https://guriensino.unipampa.edu.br/guri/public/themes/moder//imgs/marcador-lista.png", 
		"PollIntervalMs=5100", 
		"RequestCB=Poll_0_RequestCB", 
		"ResponseCB=Poll_0_ResponseCB", 
		LAST);

/* Added by Async CodeGen.
ID=Poll_1
ScanType = Recording

The following URLs are considered part of this conversation:
	https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	Poll_1_RequestCB
	Poll_1_ResponseCB
 */
	web_reg_async_attributes("ID=Poll_1", 
		"Pattern=Poll", 
		"URL=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", 
		"PollIntervalMs=5100", 
		"RequestCB=Poll_1_RequestCB", 
		"ResponseCB=Poll_1_ResponseCB", 
		LAST);

/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_0
URLs: 
	/guri/public/themes/moder//imgs/marcador-lista.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_1
URLs: 
	/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png
 */
	web_url("principal", 
		"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/marcador-lista.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/busca.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css", ENDITEM, 
		"Url=/guri/public/themes/moder//imgs/diagonals_5.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css", ENDITEM, 
		"Url=/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://guriensino.unipampa.edu.br/guri/public/js/jquery-ui-1.9.0/css/custom-theme/jquery-ui-1.8.18.custom.css", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("{matricula}", 
		"URL=https://guriensino.unipampa.edu.br/guri/ptl/sistema/getDadosPesquisaAndifesAlunoAjax/{matricula}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_0
URLs: 
	/guri/public/themes/moder//imgs/marcador-lista.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_1
URLs: 
	/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png
 */
	web_url("painel",
		"URL=https://guriensino.unipampa.edu.br/guri/pta/painel/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://guriensino.unipampa.edu.br/guri/ptl/sistema/principal",
		"Snapshot=t33.inf",
		"Mode=HTML",
		EXTRARES,
		"Url=http://detectportal.firefox.com/success.txt","Referer=",ENDITEM,
		"Url=/guri/public/themes/moder//imgs/busca.png","Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css",ENDITEM,
		"Url=/guri/public/themes/moder//imgs/diagonals_3.png","Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_admin.css",ENDITEM,
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_0
URLs: 
	/guri/public/themes/moder//imgs/marcador-lista.png
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = Poll_1
URLs: 
	/guri/public/js/jquery-ui-1.9.0/css/custom-theme/images/ui-bg_flat_75_ffffff_40x100.png
 */
	web_url("listar",
		"URL=https://guriensino.unipampa.edu.br/guri/pta/relatorios/listar/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://guriensino.unipampa.edu.br/guri/pta/painel/",
		"Snapshot=t34.inf",
		"Mode=HTML",
		EXTRARES,
		"Url=http://detectportal.firefox.com/success.txt","Referer=",ENDITEM,
		"Url=/guri/public/themes/moder//imgs/busca.png","Referer=https://guriensino.unipampa.edu.br/guri/public/themes/moder//css/estilo_menu.css",ENDITEM,
		LAST);

lr_think_time(4);

/* Added by Async CodeGen.
ID = Poll_1
 */
	web_stop_async("ID=Poll_1", 
		LAST);

/* Added by Async CodeGen.
ID = Poll_0
 */
	web_stop_async("ID=Poll_0", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_image("Clique para gerar o relat�rio", 
		"Alt=Clique para gerar o relat�rio", 
		"Ordinal=1", 
		"Snapshot=t35.inf", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		LAST);

	return 0;
}